@echo off
python src-risto\main.py