import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtCore import QUrl

def resource_path(relative_path):
    # PyInstaller support
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    
    return os.path.join(base_path, relative_path)

app = QApplication(sys.argv)

window = QWebEngineView()
window.setWindowTitle("My Risto App")

# 👇 THIS is the important part
html_path = resource_path("src/index.html")

window.load(QUrl.fromLocalFile(html_path))

window.resize(1000, 600)
window.show()

sys.exit(app.exec())